import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DrRegistrationComponent } from './dr-registration/dr-registration.component';
import { LoginPageComponent } from './login-page/login-page.component';

import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { MaterialLayoutComponent } from './material-layout/material-layout.component';
import { HomeComponent } from './home/home.component';
import { ProfileComponent } from './profile/profile.component';
import { PrescriptionComponent } from './prescription/prescription.component';
import { TranscribeComponent } from './transcribe/transcribe.component';
import { UploadComponent } from './upload/upload.component';

const routes: Routes = [
  { path:'',component:LoginComponent},
  { path: 'login', component: LoginComponent },
  {path:'login-page',component:LoginPageComponent},
  {path:'register',component:RegisterComponent},
  {path:'dr-registration',component:DrRegistrationComponent},
{ path: 'app', component: MaterialLayoutComponent,
  children: [
    { path: '', redirectTo: 'Home', pathMatch: 'full' },
    { path: 'Home', component: HomeComponent },
    {path:'profile',component:ProfileComponent},
    {path:'prescription',component:PrescriptionComponent},
    {path:'transcribe',component:TranscribeComponent},
    {path:'upload',component:UploadComponent},
  ]
}
  
 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
