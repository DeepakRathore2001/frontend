import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, ValidationErrors, Validators } from '@angular/forms';
import { LoginService } from '../login.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-dr-registration',
  templateUrl: './dr-registration.component.html',
  styleUrls: ['./dr-registration.component.css']
})
export class DrRegistrationComponent implements OnInit {
  myForm: FormGroup;
  successMessage:string='';
  errorMessage:string='';
  constructor(private fb: FormBuilder ,private loginService:LoginService,private router: Router,) {
    this.myForm = this.fb.group({
      fullName: ['', [Validators.required]],
      age: ['', [Validators.required, Validators.min(1), Validators.max(100)]],
      email: ['', [Validators.required, Validators.email]],
      gender: ['', [Validators.required]],
      phone: ['', [Validators.required, Validators.pattern(/^[0-9]{10}$/)]],
      emergency: ['', [Validators.required, Validators.pattern(/^\d{10}$/)]],
      address: ['', [Validators.required]],
      Qualification: ['', [Validators.required]],
      Specialisation: ['', [Validators.required]],
      Experience: ['', [Validators.required]],
      License: ['', [Validators.required]],
      certificate: ['', [Validators.required]],
    signature: ['', [Validators.required]],
    });
  }

  ngOnInit(): void {}

  isFieldValid(field: string): boolean {
    const control = this.myForm.get(field);
    return control?.valid && (control?.touched || control?.dirty) || false;
  }
  onSubmit(): void {
    if (this.myForm.valid) {
      this.loginService.registerDoctor(this.myForm.value)
        .subscribe({
          next: (response) => {
            this.router.navigate(['/login']);
            // Alternatively, display a success message
            this.successMessage = 'Registration successful!';  // Handle the response, e.g., navigate or display a success message
          },
          error: (error) => {
            this.errorMessage = 'Registration failed. Please try again.';  // Handle errors, e.g., display an error message
          }
        });
    }
  }
}