public interface medications {

}
