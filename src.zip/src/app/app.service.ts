import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, catchError, throwError } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AppService {

  constructor(private http: HttpClient) {}
  private prescriptionSource = new BehaviorSubject<string>('');
  currentPrescription = this.prescriptionSource.asObservable();
  updatePrescription(prescription: string) {
    this.prescriptionSource.next(prescription);
  }
 
  uploadFile(authToken: string, file: File): Observable<any> {
    const formData = new FormData();
    formData.append('file', file);
    const headers = new HttpHeaders({ 'Authorization': authToken });
    return this.http.post('http://localhost:8081/api/medassist/upload', formData, { headers, responseType: 'text' as 'json' })
      .pipe(catchError(error => throwError(error)));
  }

  
 
  generatePrescription(authToken: string, prompt: string): Observable<any> {
    const headers = new HttpHeaders({ 'Authorization': authToken, 'prompt': prompt });
    return this.http.get('http://localhost:8081/api/medassist/generatePrescription', { headers, responseType: 'text' as 'json' })
      .pipe(catchError(error => throwError(error)));
  }
}
