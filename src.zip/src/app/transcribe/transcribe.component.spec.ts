import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TranscribeComponent } from './transcribe.component';

describe('TranscribeComponent', () => {
  let component: TranscribeComponent;
  let fixture: ComponentFixture<TranscribeComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TranscribeComponent]
    });
    fixture = TestBed.createComponent(TranscribeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
