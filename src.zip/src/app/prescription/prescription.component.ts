import { Component } from '@angular/core';
import { AppService } from '../app.service';

@Component({
  selector: 'app-prescription',
  templateUrl: './prescription.component.html',
  styleUrls: ['./prescription.component.css']
})
export class PrescriptionComponent {
  prescription ='';
name='Dr John Doe';


  constructor(private  uploadService: AppService) {}
  
  ngOnInit() {

  }
}   
 
// Define the downloadPrescription function outside the class
function downloadPrescription() {
  const filename = 'prescription.component.html';
  const content = document.documentElement.outerHTML; // Get the entire HTML content
 
  const blob = new Blob([content], { type: 'text/html' });
  const url = URL.createObjectURL(blob);
 
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
 
  // Clean up
  URL.revokeObjectURL(url);

}

import { Component } from '@angular/core';
import { AppService } from '../app.service';

interface Prescription {
  nameOfMedication: string;
  dosage: string;
  frequencyOfConsumption: string;
  durationOfConsumption: string;
}

@Component({
  selector: 'app-prescription',
  template: `
    <table>
      <tr>
        <th>Name of Medication</th>
        <th>Dosage</th>
        <th>Frequency of Consumption</th>
        <th>Duration of Consumption</th>
        <th>Actions</th>
      </tr>
      <tr *ngFor="let prescription of prescriptions; let i = index">
        <td><input [(ngModel)]="prescriptions[i].nameOfMedication" /></td>
        <td><input [(ngModel)]="prescriptions[i].dosage" /></td>
        <td><input [(ngModel)]="prescriptions[i].frequencyOfConsumption" /></td>
        <td><input [(ngModel)]="prescriptions[i].durationOfConsumption" /></td>
        <td><button (click)="updatePrescription(i)">Update</button></td>
      </tr>
    </table>
  `,
  styleUrls: ['./prescription.component.css']
})
export class PrescriptionComponent {
  prescriptions: Prescription[] = [];

  constructor(private appService: AppService) {
    this.fetchPrescriptions();
  }

  fetchPrescriptions() {
    // Call the generatePrescription function from your service
    this.appService.generatePrescription().subscribe(
      (response: string) => {
        // Parse the string response into JSON objects and assign to prescriptions array
        this.prescriptions = this.parsePrescriptionResponse(response);
      },
      error => {
        console.error('Failed to fetch prescriptions:', error);
      }
    );
  }

  parsePrescriptionResponse(response: string): Prescription[] {
    // Split the response by new lines and filter out empty strings
    const prescriptionStrings = response.split('\\n').filter(str => str.trim());
    // Map each JSON string to a Prescription object
    return prescriptionStrings.map(prescriptionStr => JSON.parse(prescriptionStr));
  }

  updatePrescription(index: number) {
    const updatedPrescription = this.prescriptions[index];
    // Call service to update prescription
    console.log('Updated Prescription:', updatedPrescription);
  }
}

