import { Component } from '@angular/core';
import {  OnInit, HostBinding } from '@angular/core';
import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { Observable } from 'rxjs';
import { map, shareReplay } from 'rxjs/operators';
import { Router } from '@angular/router';
import { MatSidenav } from '@angular/material/sidenav';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-material-layout',
  templateUrl: './material-layout.component.html',
  styleUrls: ['./material-layout.component.css']
})
export class MaterialLayoutComponent {


  constructor(private breakpointObserver: BreakpointObserver,
              private router: Router,
              private _snackBar: MatSnackBar
             ) { }
             
             public mobile!: boolean;
             public loading!: boolean;
             public isAuthenticated!: boolean;
             public title!: string;
           
             public isBypass!: boolean;
             
             public isMenuInitOpen!: boolean;
             private sidenav!: MatSidenav;

    public isMenuOpen = true;
    public contentMargin = 600;

    get isHandset(): boolean {
      return this.breakpointObserver.isMatched(Breakpoints.Handset);
  }


  ngOnInit() {
    this.isMenuOpen = false;  // Open side menu by default
    this.title = 'Medi';
  }

  ngDoCheck() {
      if (this.isHandset) {
         this.isMenuOpen = true;
      } else {
         this.isMenuOpen = false;
      }
  }

  public openSnackBar(msg: string): void {
    this._snackBar.open(msg, 'X', {
      duration: 2000,
      horizontalPosition: 'center',
      verticalPosition: 'top',
      panelClass: 'notif-error'
    });
  }

  public onSelectOption(option: any): void {
    const msg = `Chose option ${option}`;
    this.openSnackBar(msg);

    /* To route to another page from here */
    // this.router.navigate(['/home']);
  }
  public logout(){
    // sessionStorage.removeItem('token');
  
  sessionStorage.getItem('token');
    sessionStorage.clear();
    console.log(sessionStorage.getItem('token'));

    this.router.navigate(['/login']);
  }
}
