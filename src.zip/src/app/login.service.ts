import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  constructor(private http: HttpClient) {}


private loginUrl ="http://localhost:8080/api/auth/login";
  login(email: string, password: string): Observable<any> {
    return this.http.post(this.loginUrl, { email, password });
  }
  
  
  private registerUrl = 'http://localhost:8080/api/auth/register'; // URL to your Spring Boot backend
  registerDoctor(signUpRequest: any): Observable<any> {
    return this.http.post(this.registerUrl, signUpRequest);
  }
  

  getToken(): string | null {
    return sessionStorage.getItem('token');
  }
}
