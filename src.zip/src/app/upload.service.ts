import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { catchError } from 'rxjs/operators';
 
@Injectable({
  providedIn: 'root'
})
export class UploadService {
 
  constructor(private http: HttpClient) {}
 
  uploadFile(authToken: string, file: File): Observable<any> {
    const formData = new FormData();
    formData.append('file', file);
    const headers = new HttpHeaders({ 'Authorization': authToken });
    return this.http.post('http://localhost:8081/api/medassist/upload', formData, { headers, responseType: 'text' as 'json' })
      .pipe(catchError(error => throwError(error)));
  }

  
 
  generatePrescription(authToken: string, prompt: string): Observable<any> {
    const headers = new HttpHeaders({ 'Authorization': authToken, 'prompt': prompt });
    return this.http.get('http://localhost:8081/api/medassist/generatePrescription', { headers, responseType: 'text' as 'json' })
      .pipe(catchError(error => throwError(error)));
  }
}