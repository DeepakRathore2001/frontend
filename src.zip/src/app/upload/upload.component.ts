import { Component } from '@angular/core';
import { AppService } from '../app.service';

@Component({
  selector: 'app-upload',
  templateUrl: './upload.component.html',
  styleUrls: ['./upload.component.css']
})
export class UploadComponent {
  title = 'MediAssist';
  selectedFile: File | null = null;
  transcription = '';
  analysis = '';
  authToken = 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJjbGllbnRfaWQiOiJqb2huQGpvaG4uY29tIn0.C7ZM47jRHCbh22EG2CMaU6k2DncAUmG-2KnGCeX8HYI';  // Ideally, this should be managed by an auth service
 
  constructor(private uploadService: AppService) {}
 
  onFileSelected(event: Event) {
    const target = event.target as HTMLInputElement;
    if (target && target.files && target.files.length > 0) {
      this.selectedFile = target.files[0];
    } else {
      this.selectedFile = null;
      console.error('No file selected');
    }
  }
 
  upload() {
    if (this.selectedFile) {
      this.uploadService.uploadFile(this.authToken, this.selectedFile).subscribe(
        response => {
          console.log('Upload successful', response);
          this.transcription = response
          // this.generatePrescription();
        },
        error => {
          console.error('Failed to upload file:', error);
        }
      );
    } else {
      console.error('No file selected for upload.');
    }
  }

  analyze(){
    
  }
 
  generatePrescription() {
    if (this.selectedFile) {
      this.uploadService.generatePrescription(this.authToken, this.transcription).subscribe(
        response => {
          console.log('Prescription Generated', response);
          this.analysis = response; // Assuming response contains the prescription
          this.uploadService.updatePrescription(this.analysis);
        },
        error => {
          console.error('Failed to generate prescription:', error);
        }
      );
    } else {
      console.error('No file selected for prescription generation.');
    }
  }
}
