import { Component } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, ValidationErrors, Validators } from '@angular/forms';
import { LoginService } from '../login.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {

  // loginForm: FormGroup;

  // constructor(private fb: FormBuilder) {
  //   this.loginForm = this.fb.group({
  //     // Define your form controls here
  //     email: ['', Validators.required],
  //     password: ['', Validators.required],
  //     // Other form controls...
  //   });
  // }

  // ngOnInit() {
  //   // Other initialization logic...
  // }

  // onSubmit() {
  //   // Handle form submission here
  //   if (this.loginForm.valid) {
  //     // Perform necessary actions (e.g., submit data to server)
  //     console.log('Form submitted successfully!');
  //   }
  // } 
  
  loginForm: FormGroup = new FormGroup({
    // Initialize your form controls here
  });
  

  constructor(private fb: FormBuilder , private loginService:LoginService,private router: Router) {}

  ngOnInit(): void {
    // Initialize the form controls with validators
    this.loginForm = this.fb.group({

      roles: ['', Validators.required],
      email: ['', [Validators.required, this.validateEmail]],
      password: ['', [Validators.required, Validators.minLength(8)]],

    });
  }
    myError(controlName: string, errorType: string): boolean {
      const control = this.loginForm.get(controlName);
      return control?.hasError(errorType) ?? false;
    }

    validateEmail(control: AbstractControl): ValidationErrors | null {
      const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
      const isValid = emailPattern.test(control.value);
    
      return isValid ? null : { invalidEmail: true };
    }

    onSubmit(): void {
      // if (this.loginForm.valid) {
        console.log(this.loginForm.value);
        this.loginService.login(this.loginForm.value.email, this.loginForm.value.password)
          .subscribe({
            next: (response) => {
             
            if(response.accessToken){
              sessionStorage.setItem('token', response.accessToken);
            console.log("session token:",sessionStorage.getItem('token'));
              sessionStorage.setItem('name', response.username);
              sessionStorage.setItem('email', response.email);
              this.router.navigate(['/app/Home']);
            }else{
           console.log(response);
            }
              // Handle successful response, e.g., navigate to dashboard
            },
            error: (error) => {
              // Handle error, e.g., show login error message
            }
          });
      // }
      // else{console.log("Invalid Form");

      // }
    }



}
