import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {
  loginForm: FormGroup = new FormGroup({
    // Initialize your form controls here
  });
  

  constructor(private fb: FormBuilder) {}

  ngOnInit(): void {
    // Initialize the form controls with validators
    this.loginForm = this.fb.group({

      roles: ['', Validators.required],
    });
}
myError(controlName: string, errorType: string): boolean {
  const control = this.loginForm.get(controlName);
  return control?.hasError(errorType) ?? false;
}
}